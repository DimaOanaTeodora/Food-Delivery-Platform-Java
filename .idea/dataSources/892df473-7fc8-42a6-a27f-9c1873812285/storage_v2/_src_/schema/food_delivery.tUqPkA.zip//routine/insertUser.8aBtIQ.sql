create
    definer = root@localhost procedure insertUser(INOUT name varchar(30), IN email varchar(30),
                                                  IN phoneNumber varchar(10), IN password varchar(30))
BEGIN
insert into user(name, email, phoneNumber, password) 
values (name, email, phoneNumber, password);
END;

